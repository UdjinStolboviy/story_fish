import Error404 from "@/pages/404";

export default {
  title: "Pages/404",
  component: Error404,
};

export const Error404Page = () => <Error404 />;
